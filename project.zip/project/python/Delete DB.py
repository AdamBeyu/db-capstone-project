import mysql.connector
mydb = mysql.connector.connect(host="localhost",password="Admin", user="root" ,database="booking")

mycursor = mydb.cursor()
import mysql.connector
mydb = mysql.connector.connect(host="localhost",password="Admin", user="root" ,database="booking")

mycursor = mydb.cursor()
sql = "DELETE FROM booking WHERE BookingName= 'math'"
mycursor.execute(sql)
mydb.commit()
