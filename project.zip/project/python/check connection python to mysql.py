import mysql.connector
mydb = mysql.connector.connect(host="localhost",password="Admin", user="root")

print(mydb)
if(mydb):
    print("connection success")
else:
    print("connection not successful")
