import mysql.connector
mydb = mysql.connector.connect(host="localhost",password="Admin", user="root" ,database="booking")

mycursor = mydb.cursor()
sql = "update customer set name= 'adam' WHERE name= 'feru'"
mycursor.execute(sql)
mydb.commit()

