import mysql.connector
mydb = mysql.connector.connect(host="localhost",password="Admin", user="root", database ="booking")

mycursor = mydb.cursor()
mycursor.execute("select * from booking")
myresult =mycursor.fetchall()
for row in myresult:
    print(row)
